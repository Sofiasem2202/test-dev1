import React from "react";
import { FieldLayout } from "../../element/layout/layout.field";

function AuthSuccessfullyPage() {
  return (
    <FieldLayout>
      <h1>Congratulations On Your Authorization</h1>
    </FieldLayout>
  );
}

export default AuthSuccessfullyPage;
